package com.parallel6.cloudconfig.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.parallel6.cloudconfig.java.controller",
								"com.parallel6.cloudconfig.java.service", 
								"com.parallel6.cloudconfig.java.repository",
								"com.parallel6.cloudconfig.java.model" })
public class ConfigclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigclientApplication.class, args);
	}

}
