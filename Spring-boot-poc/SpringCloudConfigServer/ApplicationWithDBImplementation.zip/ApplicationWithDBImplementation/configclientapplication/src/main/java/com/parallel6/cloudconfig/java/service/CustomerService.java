package com.parallel6.cloudconfig.java.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.parallel6.cloudconfig.java.model.Customer;
import com.parallel6.cloudconfig.java.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;

	public void save(Customer customer) {
		customerRepository.save(customer);		
	}

}
