package com.parallel6.cloudconfig.java.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity	
public class Customer {
	
	@Id
	@GeneratedValue
	@Column
	private int cId;
	@Column
	private String cName;
	
	
	public Customer() {
		super();
	}
	
	public Customer(int cId, String cName) {
		super();
		this.cId = cId;
		this.cName = cName;
	}
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	
	

}
